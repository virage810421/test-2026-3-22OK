# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass(frozen=True)
class FeatureSpec:
    name: str
    bucket: str
    source: str
    description: str
    is_new_in_v83_feature_stack: bool = False
    mounted_in_live_path: bool = True
    percentile_backed: bool = False
    event_calendar_precise: bool = False
    feature_family: str = 'shared'
    strategy_scope: str = 'SHARED'
    approval_scope: str = 'candidate_only'
    is_live_safe: bool = True


def _fs(name: str, bucket: str, source: str, description: str,
        is_new: bool = False, mounted: bool = True,
        percentile_backed: bool = False, event_calendar_precise: bool = False,
        feature_family: str = 'shared', strategy_scope: str = 'SHARED',
        approval_scope: str = 'candidate_only', is_live_safe: bool = True) -> FeatureSpec:
    return FeatureSpec(
        name, bucket, source, description, is_new, mounted, percentile_backed, event_calendar_precise,
        feature_family, strategy_scope, approval_scope, is_live_safe
    )


FEATURE_SPECS: Dict[str, FeatureSpec] = {
    'K_Body_Pct': _fs('K_Body_Pct', 'price_action', 'OHLCV', 'Candlestick body percentage.'),
    'Upper_Shadow': _fs('Upper_Shadow', 'price_action', 'OHLCV', 'Upper shadow relative size.'),
    'Lower_Shadow': _fs('Lower_Shadow', 'price_action', 'OHLCV', 'Lower shadow relative size.'),
    'Dist_to_MA20': _fs('Dist_to_MA20', 'price_action', 'OHLCV', 'Distance to 20-day moving average.'),
    'Volume_Ratio': _fs('Volume_Ratio', 'tradeability', 'OHLCV', 'Volume divided by 20-day volume MA.'),
    'BB_Width': _fs('BB_Width', 'volatility', 'OHLCV', 'Bollinger band width.'),
    'RSI': _fs('RSI', 'momentum', 'OHLCV', 'Relative strength index.'),
    'MACD_Hist': _fs('MACD_Hist', 'momentum', 'OHLCV', 'MACD histogram.'),
    'ADX': _fs('ADX', 'trend', 'OHLCV', 'Average directional index.'),
    'Foreign_Ratio': _fs('Foreign_Ratio', 'chip_flow', 'SQL daily_chip_data', 'Foreign net flow divided by price proxy.'),
    'Trust_Ratio': _fs('Trust_Ratio', 'chip_flow', 'SQL daily_chip_data', 'Trust net flow divided by price proxy.'),
    'Total_Ratio': _fs('Total_Ratio', 'chip_flow', 'SQL daily_chip_data', 'Combined net flow divided by price proxy.'),
    'Foreign_Consec_Days': _fs('Foreign_Consec_Days', 'chip_flow', 'SQL daily_chip_data', 'Consecutive positive foreign-flow days.'),
    'Trust_Consec_Days': _fs('Trust_Consec_Days', 'chip_flow', 'SQL daily_chip_data', 'Consecutive positive trust-flow days.'),
    'Weighted_Buy_Score': _fs('Weighted_Buy_Score', 'signal_score', 'screening/scoring', 'Weighted bullish score.'),
    'Weighted_Sell_Score': _fs('Weighted_Sell_Score', 'signal_score', 'screening/scoring', 'Weighted bearish score.'),
    'Score_Gap': _fs('Score_Gap', 'signal_score', 'screening/scoring', 'Buy score minus sell score.'),
    'Signal_Conflict': _fs('Signal_Conflict', 'risk', 'screening/scoring', 'Both buy and sell conditions active.'),
    'Trap_Signal': _fs('Trap_Signal', 'pattern', 'OHLCV', 'Fake breakout / bear trap state.'),
    'Vol_Squeeze': _fs('Vol_Squeeze', 'volatility', 'OHLCV', 'Low-volatility squeeze flag.'),
    'Absorption': _fs('Absorption', 'chip_flow', 'OHLCV + chip', 'Negative price move with positive chip support.'),
    'MR_Long_Spring': _fs('MR_Long_Spring', 'mean_reversion', 'OHLCV + chip', 'Spring-like long setup.'),
    'MR_Short_Trap': _fs('MR_Short_Trap', 'mean_reversion', 'OHLCV', 'Short-trap mean reversion setup.'),
    'MR_Long_Accumulation': _fs('MR_Long_Accumulation', 'mean_reversion', 'OHLCV + chip', 'Long accumulation state.'),
    'MR_Short_Distribution': _fs('MR_Short_Distribution', 'mean_reversion', 'OHLCV + chip', 'Short distribution state.'),
    'ATR14': _fs('ATR14', 'volatility', 'OHLCV', 'Average true range over 14 bars.', True),
    'ATR_Pct': _fs('ATR_Pct', 'volatility', 'OHLCV', 'ATR divided by close price.', True),
    'ATR_Pctl_252': _fs('ATR_Pctl_252', 'volatility', 'OHLCV', 'Rolling percentile rank of ATR_Pct over 252 bars.', True, True, True),
    'RealizedVol_20': _fs('RealizedVol_20', 'volatility', 'OHLCV', '20-day annualized realized volatility.', True),
    'RealizedVol_60': _fs('RealizedVol_60', 'volatility', 'OHLCV', '60-day annualized realized volatility.', True),
    'Gap_Pct': _fs('Gap_Pct', 'price_action', 'OHLCV', 'Open versus previous close gap.', True),
    'Overnight_Return': _fs('Overnight_Return', 'price_action', 'OHLCV', 'Previous close to open return.', True),
    'Intraday_Return': _fs('Intraday_Return', 'price_action', 'OHLCV', 'Open to close return.', True),
    'Turnover_Proxy': _fs('Turnover_Proxy', 'tradeability', 'OHLCV', 'Price times volume proxy for turnover.', True),
    'ADV20_Proxy': _fs('ADV20_Proxy', 'tradeability', 'OHLCV', '20-day average turnover proxy.', True),
    'DollarVol20_Proxy': _fs('DollarVol20_Proxy', 'tradeability', 'OHLCV', '20-day average dollar volume proxy.', True),
    'Volume_Z20': _fs('Volume_Z20', 'tradeability', 'OHLCV', '20-day z-score of volume.', True),
    'Return_Z20': _fs('Return_Z20', 'momentum', 'OHLCV', '20-day z-score of daily return.', True),
    'RS_vs_Market_20': _fs('RS_vs_Market_20', 'cross_sectional', 'Benchmark close / market snapshot', '20-day relative strength versus market benchmark.', True),
    'RS_vs_Sector_20': _fs('RS_vs_Sector_20', 'cross_sectional', 'Sector snapshot / sector classifier', '20-day relative strength versus sector benchmark.', True),
    'Revenue_YoY_Rank': _fs('Revenue_YoY_Rank', 'fundamentals', 'monthly revenue / full-market percentile snapshot', 'Official full-market percentile of revenue YoY.', True, True, True),
    'Chip_Total_Ratio_Rank': _fs('Chip_Total_Ratio_Rank', 'chip_flow', 'daily chip / full-market percentile snapshot', 'Official full-market percentile of total chip ratio.', True, True, True),
    'Event_Days_Since_Revenue': _fs('Event_Days_Since_Revenue', 'events', 'monthly revenue calendar', 'Days since most recent revenue-release date.', True, True, False, True),
    'Earnings_Window_Flag': _fs('Earnings_Window_Flag', 'events', 'quarterly fundamentals calendar', '1 if within earnings-event window.', True, True, False, True),
    'Regime_TrendStrength_X_ScoreGap': _fs('Regime_TrendStrength_X_ScoreGap', 'interaction', 'OHLCV + scoring', 'ADX normalized multiplied by score gap.', True),
    'Volatility_X_SignalConflict': _fs('Volatility_X_SignalConflict', 'interaction', 'OHLCV + scoring', 'ATR percentile multiplied by signal conflict.', True),
    'RS_vs_Market_20_Pctl': _fs('RS_vs_Market_20_Pctl', 'cross_sectional', 'full-market percentile snapshot', 'Official full-market percentile of RS_vs_Market_20.', True, True, True),
    'RS_vs_Sector_20_Pctl': _fs('RS_vs_Sector_20_Pctl', 'cross_sectional', 'full-market percentile snapshot', 'Official full-market percentile of RS_vs_Sector_20.', True, True, True),
    'Revenue_YoY_Pctl': _fs('Revenue_YoY_Pctl', 'fundamentals', 'full-market percentile snapshot', 'Official full-market percentile of revenue YoY.', True, True, True),
    'Chip_Total_Ratio_Pctl': _fs('Chip_Total_Ratio_Pctl', 'chip_flow', 'full-market percentile snapshot', 'Official full-market percentile of total chip ratio.', True, True, True),
    'Turnover_Pctl': _fs('Turnover_Pctl', 'tradeability', 'full-market percentile snapshot', 'Official full-market percentile of turnover proxy.', True, True, True),
    'ADV20_Pctl': _fs('ADV20_Pctl', 'tradeability', 'full-market percentile snapshot', 'Official full-market percentile of ADV20 proxy.', True, True, True),
    'ATR_Pct_Pctl': _fs('ATR_Pct_Pctl', 'volatility', 'full-market percentile snapshot', 'Official full-market percentile of ATR_Pct.', True, True, True),
    'RealizedVol_20_Pctl': _fs('RealizedVol_20_Pctl', 'volatility', 'full-market percentile snapshot', 'Official full-market percentile of RealizedVol_20.', True, True, True),
    'Event_Days_To_Revenue': _fs('Event_Days_To_Revenue', 'events', 'monthly revenue calendar', 'Days until next revenue-release date.', True, True, False, True),
    'Revenue_Window_1': _fs('Revenue_Window_1', 'events', 'monthly revenue calendar', 'Revenue event window 1 day.', True, True, False, True),
    'Revenue_Window_3': _fs('Revenue_Window_3', 'events', 'monthly revenue calendar', 'Revenue event window 3 day.', True, True, False, True),
    'Revenue_Window_5': _fs('Revenue_Window_5', 'events', 'monthly revenue calendar', 'Revenue event window 5 day.', True, True, False, True),
    'Revenue_Window_10': _fs('Revenue_Window_10', 'events', 'monthly revenue calendar', 'Revenue event window 10 day.', True, True, False, True),
    'Event_Days_Since_Earnings': _fs('Event_Days_Since_Earnings', 'events', 'quarterly fundamentals calendar', 'Days since most recent earnings date.', True, True, False, True),
    'Event_Days_To_Earnings': _fs('Event_Days_To_Earnings', 'events', 'quarterly fundamentals calendar', 'Days until next earnings date.', True, True, False, True),
    'Earnings_Window_3': _fs('Earnings_Window_3', 'events', 'quarterly fundamentals calendar', 'Earnings event window 3 day.', True, True, False, True),
    'Earnings_Window_7': _fs('Earnings_Window_7', 'events', 'quarterly fundamentals calendar', 'Earnings event window 7 day.', True, True, False, True),
    'Earnings_Window_14': _fs('Earnings_Window_14', 'events', 'quarterly fundamentals calendar', 'Earnings event window 14 day.', True, True, False, True),
    'Dividend_Window_7': _fs('Dividend_Window_7', 'events', 'dividend calendar', 'Dividend event window 7 day.', True, True, False, True),
}

FEATURE_SPECS.update({
    'PreEntry_Long_Score': _fs('PreEntry_Long_Score', 'entry_state_machine', 'screening/state machine', 'Preemptive long-layout score.', True, True, False, False, 'shared', 'LONG_ONLY', 'live_vetted', True),
    'PreEntry_Short_Score': _fs('PreEntry_Short_Score', 'entry_state_machine', 'screening/state machine', 'Preemptive short-layout score.', True, True, False, False, 'shared', 'SHORT_ONLY', 'live_vetted', True),
    'PreEntry_Range_Score': _fs('PreEntry_Range_Score', 'entry_state_machine', 'screening/state machine', 'Preemptive range-layout score.', True, True, False, False, 'shared', 'RANGE_ONLY', 'live_vetted', True),
    'PreEntry_Score': _fs('PreEntry_Score', 'entry_state_machine', 'screening/state machine', 'Dominant preentry score used by state machine.', True),
    'Confirm_Long_Score': _fs('Confirm_Long_Score', 'entry_state_machine', 'screening/state machine', 'Confirmed-entry long score.', True),
    'Confirm_Short_Score': _fs('Confirm_Short_Score', 'entry_state_machine', 'screening/state machine', 'Confirmed-entry short score.', True),
    'Confirm_Range_Score': _fs('Confirm_Range_Score', 'entry_state_machine', 'screening/state machine', 'Confirmed-entry range score.', True),
    'Confirm_Entry_Score': _fs('Confirm_Entry_Score', 'entry_state_machine', 'screening/state machine', 'Dominant confirmed-entry score used by state machine.', True),
    'Legacy_Long_Confirm_Pressure': _fs('Legacy_Long_Confirm_Pressure', 'entry_state_machine', 'legacy c2-c9', 'Legacy confirmation pressure from bullish c2-c9 ladder.', True),
    'Legacy_Short_Confirm_Pressure': _fs('Legacy_Short_Confirm_Pressure', 'entry_state_machine', 'legacy c2-c9', 'Legacy confirmation pressure from bearish c2-c9 ladder.', True),
    'Legacy_Range_Confirm_Pressure': _fs('Legacy_Range_Confirm_Pressure', 'entry_state_machine', 'legacy scoring', 'Legacy score neutrality used for range confirmation.', True),
    'Watch_Eligible': _fs('Watch_Eligible', 'entry_state_machine', 'screening/state machine', '1 if watch/prepare path is eligible.', True),
    'Pilot_Eligible': _fs('Pilot_Eligible', 'entry_state_machine', 'screening/state machine', '1 if pilot-entry path is eligible.', True),
    'Full_Eligible': _fs('Full_Eligible', 'entry_state_machine', 'screening/state machine', '1 if full confirmed-entry path is eligible.', True),
    'Pilot_Position_Multiplier': _fs('Pilot_Position_Multiplier', 'entry_state_machine', 'screening/state machine', 'Position-size multiplier for pilot path.', True),
    'Full_Position_Multiplier': _fs('Full_Position_Multiplier', 'entry_state_machine', 'screening/state machine', 'Position-size multiplier for confirmed path.', True),
    'StateMachine_Kelly_Pos': _fs('StateMachine_Kelly_Pos', 'entry_state_machine', 'screening/state machine', 'Kelly allocation after state-machine scaling.', True),
    'Confirm_Transition_Aligned': _fs('Confirm_Transition_Aligned', 'entry_state_machine', 'screening/state machine', '1 if transition and dominant lane are aligned for confirmation.', True),
    'Early_Path_State': _fs('Early_Path_State', 'entry_state_machine', 'screening/state machine', 'Early-layout state (NO_ENTRY/PREPARE/PILOT_ENTRY).', True, True, False, False, 'shared', 'SHARED', 'live_vetted', False),
    'Confirm_Path_State': _fs('Confirm_Path_State', 'entry_state_machine', 'screening/state machine', 'Confirmation path state (WAIT_CONFIRM/FULL_ENTRY).', True, True, False, False, 'shared', 'SHARED', 'live_vetted', False),
    'Entry_State': _fs('Entry_State', 'entry_state_machine', 'screening/state machine', 'Final state-machine action state.', True, True, False, False, 'shared', 'SHARED', 'live_vetted', False),
    'Entry_Path': _fs('Entry_Path', 'entry_state_machine', 'screening/state machine', 'Which path dominates current action.', True, True, False, False, 'shared', 'SHARED', 'live_vetted', False),
    'StateMachine_Direction': _fs('StateMachine_Direction', 'entry_state_machine', 'screening/state machine', 'Dominant state-machine lane/direction.', True, True, False, False, 'shared', 'SHARED', 'live_vetted', False),
    'Exit_State': _fs('Exit_State', 'entry_state_machine', 'screening/state machine', 'State-machine exit status (HOLD/REDUCE/DEFEND/EXIT).', True, True, False, False, 'shared', 'SHARED', 'live_vetted', False),
})

FEATURE_SPECS.update({
    'Buy_Score_Slope_3d': _fs('Buy_Score_Slope_3d', 'lead_timing', 'screening/scoring', '3-bar slope of buy score.', True),
    'Buy_Score_Slope_5d': _fs('Buy_Score_Slope_5d', 'lead_timing', 'screening/scoring', '5-bar slope of buy score.', True),
    'Sell_Score_Slope_3d': _fs('Sell_Score_Slope_3d', 'lead_timing', 'screening/scoring', '3-bar slope of sell score.', True),
    'Sell_Score_Slope_5d': _fs('Sell_Score_Slope_5d', 'lead_timing', 'screening/scoring', '5-bar slope of sell score.', True),
    'Score_Gap_Slope_3d': _fs('Score_Gap_Slope_3d', 'lead_timing', 'screening/scoring', '3-bar slope of score gap.', True),
    'Score_Gap_Slope_5d': _fs('Score_Gap_Slope_5d', 'lead_timing', 'screening/scoring', '5-bar slope of score gap.', True),
    'ADX_Delta_3d': _fs('ADX_Delta_3d', 'lead_timing', 'OHLCV', '3-bar change in ADX.', True),
    'MACD_Hist_Delta_3d': _fs('MACD_Hist_Delta_3d', 'lead_timing', 'OHLCV', '3-bar change in MACD histogram.', True),
    'RSI_Reclaim_Speed': _fs('RSI_Reclaim_Speed', 'lead_timing', 'OHLCV', 'Speed of RSI reclaim from weak state.', True),
    'BB_Squeeze_Release': _fs('BB_Squeeze_Release', 'lead_timing', 'OHLCV', 'Compression-to-release transition signal.', True),
    'ATR_Expansion_Start': _fs('ATR_Expansion_Start', 'lead_timing', 'OHLCV', 'Early-stage ATR expansion signal.', True),
    'Volume_Z20_Delta': _fs('Volume_Z20_Delta', 'lead_timing', 'OHLCV', '3-bar change in volume z-score.', True),
    'Foreign_Ratio_Delta_3d': _fs('Foreign_Ratio_Delta_3d', 'lead_timing', 'chip_flow', '3-bar change in foreign ratio.', True),
    'Total_Ratio_Delta_3d': _fs('Total_Ratio_Delta_3d', 'lead_timing', 'chip_flow', '3-bar change in total ratio.', True),
    'Bull_Emerging_Score': _fs('Bull_Emerging_Score', 'transition_regime', 'regime service', 'Probability-like score for bullish transition emerging.', True),
    'Bear_Emerging_Score': _fs('Bear_Emerging_Score', 'transition_regime', 'regime service', 'Probability-like score for bearish transition emerging.', True),
    'Range_Compression_Score': _fs('Range_Compression_Score', 'transition_regime', 'regime service', 'Compression score prior to range breakout.', True),
    'Breakout_Readiness': _fs('Breakout_Readiness', 'transition_regime', 'regime service', 'Readiness of compressed regime to break out.', True),
    'Trend_Exhaustion_Score': _fs('Trend_Exhaustion_Score', 'transition_regime', 'regime service', 'Probability-like score of trend exhaustion.', True),
    'Entry_Readiness': _fs('Entry_Readiness', 'timing', 'feature/regime fusion', 'Composite readiness for early entry.', True),
    'Breakout_Risk_Next3': _fs('Breakout_Risk_Next3', 'timing', 'regime service', 'Risk of range resolving in next ~3 bars.', True),
    'Reversal_Risk_Next3': _fs('Reversal_Risk_Next3', 'timing', 'regime service', 'Risk of trend reversal in next ~3 bars.', True),
    'Exit_Hazard_Score': _fs('Exit_Hazard_Score', 'timing', 'feature/regime fusion', 'Composite hazard score for early exit defense.', True),
    'Proba_Delta_3d': _fs('Proba_Delta_3d', 'timing', 'model/signal proxy', '3-bar change in probability proxy.', True),
    'Trend_Confidence_Delta': _fs('Trend_Confidence_Delta', 'timing', 'regime service', 'Change in trend confidence.', True),
    'Range_Confidence_Delta': _fs('Range_Confidence_Delta', 'timing', 'regime service', 'Change in range confidence.', True),
    'Regime_Label': _fs('Regime_Label', 'transition_regime', 'regime service', 'Primary regime label from regime service.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Regime_Confidence': _fs('Regime_Confidence', 'transition_regime', 'regime service', 'Confidence of primary regime label.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Next_Regime_Prob_Bull': _fs('Next_Regime_Prob_Bull', 'transition_regime', 'regime service', 'Forward bull-transition probability.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Next_Regime_Prob_Bear': _fs('Next_Regime_Prob_Bear', 'transition_regime', 'regime service', 'Forward bear-transition probability.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Next_Regime_Prob_Range': _fs('Next_Regime_Prob_Range', 'transition_regime', 'regime service', 'Forward range-transition probability.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Transition_Label': _fs('Transition_Label', 'transition_regime', 'regime service', 'Transition-state label from regime service.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Hysteresis_Regime_Label': _fs('Hysteresis_Regime_Label', 'transition_regime', 'regime service', 'Regime label after hysteresis smoothing.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Hysteresis_Stable_Bars': _fs('Hysteresis_Stable_Bars', 'transition_regime', 'regime service', 'Count of stable bars in current hysteresis regime.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Hysteresis_Switch_Armed': _fs('Hysteresis_Switch_Armed', 'transition_regime', 'regime service', '1 if regime switch is armed but not yet confirmed.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Hysteresis_Switch_Margin': _fs('Hysteresis_Switch_Margin', 'transition_regime', 'regime service', 'Margin between challenger and incumbent regime probability.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Hysteresis_Pending_Label': _fs('Hysteresis_Pending_Label', 'transition_regime', 'regime service', 'Pending regime label awaiting hysteresis confirmation.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Hysteresis_Pending_Bars': _fs('Hysteresis_Pending_Bars', 'transition_regime', 'regime service', 'Pending confirmation bar count for hysteresis switch.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Hysteresis_Regime_Changed': _fs('Hysteresis_Regime_Changed', 'transition_regime', 'regime service', '1 if hysteresis regime changed on this bar.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Hysteresis_Locked': _fs('Hysteresis_Locked', 'transition_regime', 'regime service', '1 if minimum hold constraint kept prior regime.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
})

FEATURE_BUCKETS: Dict[str, List[str]] = {}
for name, spec in FEATURE_SPECS.items():
    FEATURE_BUCKETS.setdefault(spec.bucket, []).append(name)

PRIORITY_NEW_FEATURES_20: List[str] = [
    'Score_Gap_Slope_3d', 'Score_Gap_Slope_5d', 'ADX_Delta_3d', 'MACD_Hist_Delta_3d', 'RSI_Reclaim_Speed',
    'BB_Squeeze_Release', 'ATR_Expansion_Start', 'Volume_Z20_Delta', 'Foreign_Ratio_Delta_3d', 'Total_Ratio_Delta_3d',
    'Bull_Emerging_Score', 'Bear_Emerging_Score', 'Range_Compression_Score', 'Breakout_Readiness', 'Trend_Exhaustion_Score',
    'Entry_Readiness', 'Breakout_Risk_Next3', 'Reversal_Risk_Next3', 'Exit_Hazard_Score', 'PreEntry_Score',
    'Confirm_Entry_Score', 'Proba_Delta_3d',
]


# ----- 文件8：safe directional/range feature overlay (training/research first, no direct live default) -----
FEATURE_SPECS.update({
    'Short_Failed_Rebound': _fs('Short_Failed_Rebound', 'directional_short', 'OHLCV + MA/RSI', 'Failed rebound below MA20 with weak close.', True, True, False, False, 'directional', 'SHORT_ONLY', 'live_vetted', True),
    'Short_Weak_Bounce': _fs('Short_Weak_Bounce', 'directional_short', 'OHLCV', 'Weak intraday bounce with soft close.', True, False, False, False, 'directional', 'SHORT_ONLY', 'research_and_training', False),
    'Short_Distribution_Pressure': _fs('Short_Distribution_Pressure', 'directional_short', 'OHLCV + chip', 'Distribution pressure under negative chip flow.', True, True, False, False, 'directional', 'SHORT_ONLY', 'live_vetted', True),
    'Short_Breakdown_Followthrough': _fs('Short_Breakdown_Followthrough', 'directional_short', 'OHLCV', 'Breakdown continuation under MA20.', True, False, False, False, 'directional', 'SHORT_ONLY', 'research_and_training', False),
    'Short_Upper_Shadow_Pressure': _fs('Short_Upper_Shadow_Pressure', 'directional_short', 'OHLCV', 'Upper-shadow selling pressure.', True, True, False, False, 'directional', 'SHORT_ONLY', 'live_vetted', True),
    'Short_GapDown_Continuation': _fs('Short_GapDown_Continuation', 'directional_short', 'OHLCV', 'Gap-down with weak intraday recovery.', True, False, False, False, 'directional', 'SHORT_ONLY', 'research_and_training', False),
    'Short_Below_MA20_FailedRetake': _fs('Short_Below_MA20_FailedRetake', 'directional_short', 'OHLCV + MA', 'Below-MA20 failed retake.', True, True, False, False, 'directional', 'SHORT_ONLY', 'live_vetted', True),
    'Short_RS_Weakness': _fs('Short_RS_Weakness', 'directional_short', 'cross_sectional', 'Relative-strength weakness.', True, True, True, False, 'directional', 'SHORT_ONLY', 'live_vetted', True),
    'Range_Position_Pct': _fs('Range_Position_Pct', 'directional_range', 'OHLCV rolling range', 'Position of close inside rolling range.', True, True, False, False, 'directional', 'RANGE_ONLY', 'live_vetted', True),
    'Distance_To_Range_Top': _fs('Distance_To_Range_Top', 'directional_range', 'OHLCV rolling range', 'Distance to rolling range top.', True, True, False, False, 'directional', 'RANGE_ONLY', 'live_vetted', True),
    'Distance_To_Range_Bottom': _fs('Distance_To_Range_Bottom', 'directional_range', 'OHLCV rolling range', 'Distance to rolling range bottom.', True, True, False, False, 'directional', 'RANGE_ONLY', 'live_vetted', True),
    'Range_Mean_Reversion_Score': _fs('Range_Mean_Reversion_Score', 'directional_range', 'OHLCV + RSI + Bollinger', 'Mean-reversion score inside range.', True, True, False, False, 'directional', 'RANGE_ONLY', 'live_vetted', True),
    'Range_Exhaustion_Score': _fs('Range_Exhaustion_Score', 'directional_range', 'OHLCV + RSI', 'Exhaustion score near range edge.', True, True, False, False, 'directional', 'RANGE_ONLY', 'live_vetted', True),
    'Range_Width_Pct': _fs('Range_Width_Pct', 'directional_range', 'OHLCV rolling range', 'Normalized rolling range width.', True, True, False, False, 'directional', 'RANGE_ONLY', 'live_vetted', True),
    'Range_Center_Distance': _fs('Range_Center_Distance', 'directional_range', 'OHLCV rolling range', 'Distance from rolling range center.', True, True, False, False, 'directional', 'RANGE_ONLY', 'live_vetted', True),
    'Range_Bounce_Quality': _fs('Range_Bounce_Quality', 'directional_range', 'OHLCV', 'Bounce quality near range bottom.', True, True, False, False, 'directional', 'RANGE_ONLY', 'live_vetted', True),
    'Range_Fade_Quality': _fs('Range_Fade_Quality', 'directional_range', 'OHLCV', 'Fade quality near range top.', True, True, False, False, 'directional', 'RANGE_ONLY', 'live_vetted', True),
    'Range_Confidence': _fs('Range_Confidence', 'regime_confidence', 'regime service', 'Probability-like confidence that current state is range-bound.', True, True, False, False, 'regime', 'RANGE_ONLY', 'live_vetted', True),
    'Trend_Confidence': _fs('Trend_Confidence', 'regime_confidence', 'regime service', 'Probability-like confidence that current state is trending.', True, True, False, False, 'regime', 'SHARED', 'live_vetted', True),
    'Range_Width_Pctl': _fs('Range_Width_Pctl', 'regime_confidence', 'regime service', 'Percentile of range width.', True, True, True, False, 'regime', 'RANGE_ONLY', 'live_vetted', True),
    'MA_Slope_Flatness': _fs('MA_Slope_Flatness', 'regime_confidence', 'regime service', 'Flatness of MA slope.', True, True, False, False, 'regime', 'RANGE_ONLY', 'live_vetted', True),
    'BB_Width_Pctl': _fs('BB_Width_Pctl', 'regime_confidence', 'regime service', 'Percentile of Bollinger width.', True, True, True, False, 'regime', 'RANGE_ONLY', 'live_vetted', True),
    'ADX_Low_Regime_Flag': _fs('ADX_Low_Regime_Flag', 'regime_confidence', 'regime service', 'Flag for low-ADX range-like regime.', True, True, False, False, 'regime', 'RANGE_ONLY', 'live_vetted', True),
})

FEATURE_BUCKETS = {}
for name, spec in FEATURE_SPECS.items():
    FEATURE_BUCKETS.setdefault(spec.bucket, []).append(name)

STRATEGY_SCOPE_GROUPS: Dict[str, List[str]] = {'SHARED': [], 'LONG_ONLY': [], 'SHORT_ONLY': [], 'RANGE_ONLY': []}
for name, spec in FEATURE_SPECS.items():
    STRATEGY_SCOPE_GROUPS.setdefault(spec.strategy_scope, []).append(name)

LIVE_SAFE_FEATURES: List[str] = [name for name, spec in FEATURE_SPECS.items() if spec.is_live_safe]

def get_feature_list(strategy_scope: str = 'ALL', live_safe_only: bool = False) -> List[str]:
    if strategy_scope == 'ALL':
        names = list(FEATURE_SPECS.keys())
    else:
        names = list(STRATEGY_SCOPE_GROUPS.get(strategy_scope, [])) + STRATEGY_SCOPE_GROUPS.get('SHARED', [])
        names = list(dict.fromkeys(names))
    if live_safe_only:
        names = [n for n in names if n in LIVE_SAFE_FEATURES]
    return names

def get_training_feature_groups() -> Dict[str, List[str]]:
    return {k: get_feature_list(k, live_safe_only=False) for k in ['SHARED', 'LONG_ONLY', 'SHORT_ONLY', 'RANGE_ONLY']}

def get_live_feature_groups() -> Dict[str, List[str]]:
    return {k: get_feature_list(k, live_safe_only=True) for k in ['SHARED', 'LONG_ONLY', 'SHORT_ONLY', 'RANGE_ONLY']}


APPROVED_LIVE_DIRECTIONAL_FEATURES: List[str] = [
    name for name, spec in FEATURE_SPECS.items()
    if spec.feature_family in {'directional', 'regime'} and spec.is_live_safe and spec.approval_scope in {'live_vetted', 'candidate_only'}
]


def is_feature_live_approved(name: str) -> bool:
    spec = FEATURE_SPECS.get(str(name or '').strip())
    return bool(spec and spec.is_live_safe and spec.approval_scope in {'live_vetted', 'candidate_only'})
