# ==========================================
# 中央參數總控台（升級整合版 v2.1）
# ==========================================
import csv
import os
from pathlib import Path


PARAMS = {
    "RSI_PERIOD": 14,
    "MACD_FAST": 12,
    "MACD_SLOW": 26,
    "MACD_SIGNAL": 9,
    "BB_WINDOW": 20,
    "BB_STD": 2.0,
    "VOL_WINDOW": 20,
    "MA_LONG": 60,
    "BBI_PERIODS": [3, 6, 12, 24],
    "DMI_PERIOD": 14,

    "TRIGGER_SCORE": 2,
    "ADX_TREND_THRESHOLD": 20,
    "MIN_PRICE": 10.0,
    "MIN_VOL_MA20": 1_000_000,
    "VOL_BREAKOUT_MULTIPLIER": 1.1,

    "FEE_RATE": 0.001425,
    "FEE_DISCOUNT": 0.6,
    "TAX_RATE": 0.003,

    "SL_MIN_PCT": 0.030,
    "SL_MAX_PCT": 0.080,
    "TP_BASE_PCT": 0.10,
    "TP_TREND_PCT": 0.250,

    "TOTAL_BUDGET": 10_000_000,
    "MAX_POSITIONS": 20,
    "MIN_RR_RATIO": 1.5,

    "MDD_LEVEL_1": 0.10,
    "MDD_MULTIPLIER_1": 0.5,
    "MDD_LEVEL_2": 0.15,
    "MDD_MULTIPLIER_2": 0.2,
    "MDD_LIMIT": 0.20,

    "EV_HIGH_THRESHOLD": 2.0,
    "EV_HIGH_MULTIPLIER": 1.5,
    "EV_BASE_THRESHOLD": 1.0,
    "EV_BASE_MULTIPLIER": 1.0,
    "EV_LOW_MULTIPLIER": 0.5,

    "SCAN_INTERVAL": 300,
    "MAX_BATCHES": 3,
    "MARKET_SLIPPAGE": 0.0015,

    "MIN_SIGNAL_SAMPLE_SIZE": 8,
    "ML_LABEL_HOLD_DAYS": 5,
    "MODEL_MIN_REGIME_SAMPLES": 50,
    "MODEL_SEED_FEATURE_LIMIT": 12,
    "WF_SPLITS": 5,
    "MODEL_N_ESTIMATORS": 200,
    "MODEL_MAX_DEPTH": 7,

    "MODEL_MIN_SELECTED_FEATURES": 8,
    "MODEL_MAX_SELECTED_FEATURES": 18,
    "MODEL_MIN_OOT_PF": 1.00,
    "MODEL_MIN_OOT_HIT_RATE": 0.45,
    "MODEL_MIN_PROMOTION_SCORE": 0.0,
    "MODEL_ALLOW_KEEP_TRAINED_IF_NOT_PROMOTED": True,
    "REGIME_USE_ENHANCED_CLASSIFIER": True,

    "LIVE_MONITOR_WIN_RATE": 0.30,
    "LIVE_MONITOR_MIN_AVG_RETURN": -0.20,
    "IGNORE_CASH_LIMIT": False,

    "FUNDAMENTAL_YOY_BASE": 0,
    "FUNDAMENTAL_YOY_EXCELLENT": 20,
    "FUNDAMENTAL_OPM_BASE": 0,

    # 新版加權燈號設定
    "W_C2_RSI": 0.5,
    "W_C3_VOLUME": 0.5,
    "W_C4_MACD": 1.5,
    "W_C5_BOLL": 0.5,
    "W_C6_BBI": 2.0,
    "W_C7_FOREIGN": 0.7,
    "W_C8_DMI_ADX": 2.0,
    "W_C9_TOTAL_RATIO": 0.3,

    # 訓練 / live 一致性
    "LABEL_USE_EXECUTION_AWARE": True,
    "LABEL_USE_NEXT_OPEN": True,
    "LABEL_REQUIRE_STOP_SAFE": True,
    "LIVE_REQUIRE_SELECTED_FEATURES": True,
    "LIVE_FEATURE_PARITY_MODE": "strict",
    "EXECUTION_POLICY_MODE": "explicit",
    "STRATEGY_LAYER_MODE": "independent",
    "MODEL_LAYER_MODE": "independent",
    "EXECUTION_LAYER_MODE": "independent",
}

WATCH_LIST = [
    "2330.TW",
    "2317.TW",
    "2454.TW",
    "2881.TW",
    "2603.TW",
]


TRAINING_POOL = [
    "2330.TW",
    "2317.TW",
    "2454.TW",
    "2603.TW",
    "2881.TW",
    "3231.TW",
    "1519.TW",
    "2002.TW",
    "2303.TW",
    "2308.TW",
    "2382.TW",
    "2408.TW",
    "2882.TW",
    "2891.TW",
    "3711.TW",
    "6505.TW",
]

BREAK_TEST_POOL = []
OPTIONAL_UNIVERSE_FILES = [
    Path('data/training_bootstrap_universe.csv'),
    Path('data/paper_execution_watchlist.csv'),
    Path('runtime/approved_live_watchlist.csv'),
]

# 不再把 token 寫死在程式裡。正式環境請改設環境變數。
FINMIND_API_TOKEN = os.getenv("FINMIND_API_TOKEN", "").strip()


def _normalize_ticker(v: str) -> str:
    s = str(v or '').strip().upper()
    if not s:
        return ''
    if s.endswith('.TW') or s.endswith('.TWO'):
        return s
    if s.isdigit():
        return f'{s}.TW'
    return s


def _load_optional_tickers_from_csvs() -> list[str]:
    out: list[str] = []
    env_raw = os.getenv('FTS_EXTRA_TICKERS', '').strip()
    if env_raw:
        for token in env_raw.replace(';', ',').split(','):
            ticker = _normalize_ticker(token)
            if ticker:
                out.append(ticker)
    for path in OPTIONAL_UNIVERSE_FILES:
        if not Path(path).exists():
            continue
        try:
            with open(path, 'r', encoding='utf-8-sig', newline='') as fh:
                reader = csv.DictReader(fh)
                for row in reader:
                    for col in ('Ticker SYMBOL', 'Ticker', 'ticker', 'symbol', 'stock_id', '代號'):
                        ticker = _normalize_ticker(row.get(col, ''))
                        if ticker:
                            out.append(ticker)
                            break
        except Exception:
            continue
    return out



def get_dynamic_watch_list():
    merged = []
    universe_sources = [WATCH_LIST, TRAINING_POOL, BREAK_TEST_POOL, _load_optional_tickers_from_csvs()]
    max_names = max(int(os.getenv('FTS_MAX_DYNAMIC_TICKERS', '60') or 60), len(WATCH_LIST), len(TRAINING_POOL))
    for pool in universe_sources:
        for ticker in pool:
            ticker = _normalize_ticker(ticker)
            if ticker and ticker not in merged:
                merged.append(ticker)
            if len(merged) >= max_names:
                return merged
    return merged


def get_dynamic_training_universe():
    return get_dynamic_watch_list()


# ---- Portfolio Risk Layer ----
PARAMS["PORT_MAX_SECTOR_POSITIONS"] = 2
PARAMS["PORT_MAX_SECTOR_ALLOC"] = 0.35
PARAMS["PORT_MAX_TOTAL_ALLOC"] = 0.60
PARAMS["PORT_MAX_DIRECTION_ALLOC"] = 0.45
PARAMS["PORT_MAX_SINGLE_POS"] = 0.12
PARAMS["PORT_MIN_POSITION"] = 0.01


# ---- Alert / Guard ----
PARAMS["ALERT_TEST_MODE"] = True
PARAMS["ALERT_LINE_BOT_TOKEN"] = os.getenv("ALERT_LINE_BOT_TOKEN", "").strip()
PARAMS["ALERT_LINE_USER_ID"] = os.getenv("ALERT_LINE_USER_ID", "").strip()


# ---- tri-lane final orchestration / bookkeeping ----
PARAMS.setdefault("LONG_MIN_PROBA", 0.52)
PARAMS.setdefault("SHORT_MIN_PROBA", 0.55)
PARAMS.setdefault("RANGE_MIN_PROBA", 0.53)
PARAMS.setdefault("LONG_MIN_OOT_EV", 0.0)
PARAMS.setdefault("SHORT_MIN_OOT_EV", 0.0)
PARAMS.setdefault("RANGE_MIN_OOT_EV", 0.0)
PARAMS.setdefault("LONG_MAX_HOLD_DAYS", 10)
PARAMS.setdefault("SHORT_MAX_HOLD_DAYS", 6)
PARAMS.setdefault("RANGE_MAX_HOLD_DAYS", 4)
PARAMS.setdefault("LONG_TP_PCT", 0.10)
PARAMS.setdefault("SHORT_TP_PCT", 0.08)
PARAMS.setdefault("RANGE_TP_PCT", 0.05)
PARAMS.setdefault("LONG_SL_PCT", 0.04)
PARAMS.setdefault("SHORT_SL_PCT", 0.035)
PARAMS.setdefault("RANGE_SL_PCT", 0.025)
PARAMS.setdefault("RANGE_MIN_CONFIDENCE", 0.55)
PARAMS.setdefault("LIVE_WATCHLIST_LONG_MAX_NAMES", 12)
PARAMS.setdefault("LIVE_WATCHLIST_SHORT_MAX_NAMES", 8)
PARAMS.setdefault("LIVE_WATCHLIST_RANGE_MAX_NAMES", 8)
PARAMS.setdefault("LIVE_WATCHLIST_TOTAL_MAX_NAMES", 18)
PARAMS.setdefault("LIVE_WATCHLIST_MAX_PER_SECTOR", 3)
PARAMS.setdefault("LIVE_WATCHLIST_MIN_FEATURE_COVERAGE", 0.95)
PARAMS.setdefault("LIVE_WATCHLIST_MIN_LIQUIDITY_SCORE", 0.20)
PARAMS.setdefault("LIVE_WATCHLIST_MAX_NET_SHORT_OVER_LONG", 0.60)
PARAMS.setdefault("LIVE_WATCHLIST_MAX_NET_LONG_OVER_SHORT", 1.20)
PARAMS.setdefault("ENABLE_DIRECTIONAL_REPAIR_EXECUTION", True)
PARAMS.setdefault("ENABLE_DIRECTIONAL_LEDGER_MUTATION", True)
PARAMS.setdefault("ENABLE_TRI_LANE_STAGE_RUNNERS", True)
PARAMS.setdefault("ENABLE_DIRECTIONAL_LEDGER", True)
PARAMS.setdefault("ENABLE_DIRECTIONAL_REPAIR_WORKFLOW", True)
PARAMS.setdefault("ENABLE_DIRECTIONAL_CALLBACK_PIPELINE", True)
PARAMS.setdefault("ENABLE_DIRECTIONAL_CANDIDATES_IN_LIVE", True)
PARAMS.setdefault("ENABLE_DIRECTIONAL_MODEL_LOADING", True)
PARAMS.setdefault("ENABLE_DIRECTIONAL_WATCHLIST_IN_LIVE", True)


# ---- directional strengthening pack ----
PARAMS.setdefault("ENABLE_DIRECTIONAL_ARTIFACT_BOOTSTRAP", True)
PARAMS.setdefault("DIRECTIONAL_BOOTSTRAP_FORCE_SHARED", True)
PARAMS.setdefault("DIRECTIONAL_SEED_FROM_CORE_WATCHLIST", True)
PARAMS.setdefault("DIRECTIONAL_SCOREBOARD_AUTO_BUILD", True)
PARAMS.setdefault("DIRECTIONAL_PROMOTION_MIN_COUNT", 3)
PARAMS.setdefault("LONG_SEED_SCORE", 0.35)
PARAMS.setdefault("SHORT_SEED_SCORE", 0.25)
PARAMS.setdefault("RANGE_SEED_SCORE", 0.25)
PARAMS.setdefault("SHORT_FALLBACK_FROM_CORE", True)
PARAMS.setdefault("RANGE_FALLBACK_FROM_CORE", True)
PARAMS.setdefault("LIVE_WATCHLIST_SHORT_MAX_NAMES", max(int(PARAMS.get("LIVE_WATCHLIST_SHORT_MAX_NAMES", 8)), 5))
PARAMS.setdefault("LIVE_WATCHLIST_RANGE_MAX_NAMES", max(int(PARAMS.get("LIVE_WATCHLIST_RANGE_MAX_NAMES", 8)), 5))

# ---- long/range activation + short/range event flow ----
PARAMS.setdefault("LIVE_WATCHLIST_MIN_PER_LANE_LONG", 2)
PARAMS.setdefault("LIVE_WATCHLIST_MIN_PER_LANE_SHORT", 2)
PARAMS.setdefault("LIVE_WATCHLIST_MIN_PER_LANE_RANGE", 2)
PARAMS.setdefault("LIVE_WATCHLIST_UNKNOWN_SECTOR_SOFT_CAP", True)
PARAMS.setdefault("DIRECTIONAL_DECISION_AUGMENT", True)
PARAMS.setdefault("DIRECTIONAL_DECISION_AUGMENT_MAX_PER_LANE", 2)
PARAMS.setdefault("DIRECTIONAL_DECISION_AUGMENT_USE_SCREENING", True)
PARAMS.setdefault("DIRECTIONAL_SYNTHETIC_KELLY", 0.03)
PARAMS.setdefault("LONG_SEED_SCORE", max(float(PARAMS.get("LONG_SEED_SCORE", 0.35)), 0.45))
PARAMS.setdefault("RANGE_SEED_SCORE", max(float(PARAMS.get("RANGE_SEED_SCORE", 0.25)), 0.35))


PARAMS.setdefault("LONG_MIN_CONFIDENCE", 0.50)
PARAMS.setdefault("SHORT_MIN_CONFIDENCE", 0.50)
PARAMS.setdefault("RANGE_MIN_CONFIDENCE", float(PARAMS.get("RANGE_MIN_CONFIDENCE", 0.55)))
PARAMS.setdefault("LABEL_TP_PCT", max(float(PARAMS.get("TP_BASE_PCT", 0.10)), 0.06))
PARAMS.setdefault("LABEL_MIN_POSITIVE_RETURN", 0.0)
PARAMS.setdefault("MODEL_PRIMARY_SIGNAL_GATE", True)

PARAMS.setdefault("ENABLE_DUAL_PATH_STATE_MACHINE", True)
PARAMS.setdefault("PREENTRY_WATCH_THRESHOLD", 0.42)
PARAMS.setdefault("PREENTRY_PILOT_THRESHOLD", 0.58)
PARAMS.setdefault("CONFIRM_FULL_THRESHOLD", 0.66)
PARAMS.setdefault("PILOT_ALLOC_MULTIPLIER", 0.33)
PARAMS.setdefault("FULL_ALLOC_MULTIPLIER", 1.00)
PARAMS.setdefault("PREPARE_ALLOC_MULTIPLIER", 0.00)
PARAMS.setdefault("PILOT_MIN_PROBA_BUFFER", 0.04)
PARAMS.setdefault("PILOT_MIN_CONF_BUFFER", 0.06)
PARAMS.setdefault("PILOT_MAX_BREAKOUT_RISK", 0.82)
PARAMS.setdefault("FULL_MAX_BREAKOUT_RISK", 0.72)
PARAMS.setdefault("LEGACY_CONFIRM_INFLUENCE", 0.10)
PARAMS.setdefault("LEGACY_CONFIRM_DIAGNOSTIC_ONLY", True)
PARAMS.setdefault("STATE_EXIT_REDUCE_HAZARD", 0.55)
PARAMS.setdefault("STATE_EXIT_DEFEND_HAZARD", 0.72)
PARAMS.setdefault("STATE_EXIT_HARD_EXIT", 0.88)
PARAMS.setdefault("STATE_MACHINE_CONFIRM_REQUIRES_ALIGNMENT", False)
PARAMS.setdefault("SETUP_READY_MIN_FAVORABLE_PCT", 1.50)
PARAMS.setdefault("TRIGGER_CONFIRM_MIN_FAVORABLE_PCT", 3.00)
PARAMS.setdefault("WEIGHTED_SCORE_DIAGNOSTIC_ONLY", True)
PARAMS.setdefault("RANGE_MAX_SCORE_GAP_ABS", 1.25)


# ---- bridge / legacy detachment hardening ----
PARAMS.setdefault("FORCE_SERVICE_API_ONLY", True)
PARAMS.setdefault("ALLOW_LEGACY_FACADE_IN_RESEARCH", False)
PARAMS.setdefault("ALLOW_LEGACY_FACADE_IN_LIVE", False)
PARAMS.setdefault("BRIDGE_GUARD_FAIL_CLOSED", True)
PARAMS.setdefault("PREFER_SQLALCHEMY_DB", True)
