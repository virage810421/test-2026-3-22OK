# -*- coding: utf-8 -*-
from __future__ import annotations

"""
SQL 中文欄名查詢層。

設計原則：
1. 不破壞 Python 主線與 broker/execution contract。
2. 底層正式表仍維持 fts_db_schema.py 定義的欄位，避免 logger / execution / reconciliation 壞掉。
3. 每個正式表建立一個中文欄名 VIEW，讓 SQL Server 查詢/報表可直接使用中文欄名。
4. 這不是 drop/rename 實體欄位；若未來要破壞式 sp_rename，必須另跑 destructive readiness。
"""

from typing import Any

from fts_db_schema import iter_table_specs

try:
    from fts_runtime_diagnostics import record_issue
except Exception:  # pragma: no cover - diagnostics must not block migration
    def record_issue(*args: Any, **kwargs: Any) -> dict[str, Any]:
        return {}


TABLE_VIEW_NAME_MAP: dict[str, str] = {
    'trade_history': '交易紀錄_中文欄位',
    'active_positions': '目前持倉_中文欄位',
    'daily_chip_data': '法人籌碼日資料_中文欄位',
    'execution_orders': '執行委託單_中文欄位',
    'execution_fills': '執行成交明細_中文欄位',
    'execution_account_snapshot': '執行帳戶快照_中文欄位',
    'execution_positions_snapshot': '執行持倉快照_中文欄位',
    'execution_position_lots': '執行持倉批次_中文欄位',
    'execution_broker_callbacks': '券商回報事件_中文欄位',
    'execution_reconciliation_report': '執行對帳報告_中文欄位',
    'execution_tax_lot_closures': '稅務批次平倉明細_中文欄位',
    'execution_tax_lot_summary': '稅務批次年度彙總_中文欄位',
    'fundamentals_clean': '基本面清洗資料_中文欄位',
    'monthly_revenue_simple': '月營收資料_中文欄位',
    'account_info': '帳戶資訊_中文欄位',
}

COLUMN_NAME_MAP: dict[str, str] = {
    # common / execution contract
    'order_id': '委託單ID',
    'client_order_id': '客戶委託ID',
    'broker_order_id': '券商委託ID',
    'ticker_symbol': '股票代號',
    'direction_bucket': '方向分類',
    'strategy_bucket': '策略分類',
    'strategy_name': '策略名稱',
    'status': '狀態',
    'qty': '委託數量',
    'filled_qty': '已成交數量',
    'remaining_qty': '剩餘數量',
    'avg_fill_price': '平均成交價',
    'order_type': '委託類型',
    'submitted_price': '送出價格',
    'ref_price': '參考價格',
    'reject_reason': '拒單原因',
    'signal_id': '訊號ID',
    'industry': '產業類別',
    'signal_score': '訊號分數',
    'ai_confidence': 'AI信心分數',
    'note': '備註',
    'created_at': '建立時間',
    'updated_at': '更新時間',
    'fill_id': '成交ID',
    'fill_qty': '成交數量',
    'fill_price': '成交價格',
    'fill_time': '成交時間',
    'commission': '手續費',
    'tax': '交易稅',
    'slippage': '滑價',
    'snapshot_time': '快照時間',
    'account_name': '帳戶名稱',
    'cash': '現金',
    'market_value': '市值',
    'equity': '權益總值',
    'buying_power': '可用購買力',
    'unrealized_pnl': '未實現損益',
    'realized_pnl': '已實現損益',
    'day_pnl': '當日損益',
    'exposure_ratio': '曝險比例',
    'currency': '幣別',
    'broker_type': '券商類型',
    'available_qty': '可用數量',
    'avg_cost': '平均成本',
    'market_price': '市價',

    # lots / callbacks / reconciliation
    'lot_id': '持倉批次ID',
    'tax_lot_id': '稅務批次ID',
    'open_qty': '開倉數量',
    'remaining_qty': '剩餘數量',
    'entry_price': '進場價格',
    'entry_time': '進場時間',
    'close_time': '平倉時間',
    'entry_order_id': '進場委託ID',
    'exit_order_id': '出場委託ID',
    'position_key': '持倉鍵',
    'cost_basis_method': '成本基礎方法',
    'entry_fill_qty': '進場成交數量',
    'close_fill_qty': '平倉成交數量',
    'entry_fill_count': '進場成交筆數',
    'close_fill_count': '平倉成交筆數',
    'entry_fill_ids_json': '進場成交ID清單',
    'exit_fill_ids_json': '出場成交ID清單',
    'open_commission': '開倉手續費',
    'open_tax': '開倉交易稅',
    'close_commission': '平倉手續費',
    'close_tax': '平倉交易稅',
    'stop_order_id': '停損委託ID',
    'stop_price': '停損價格',
    'stop_status': '停損狀態',
    'linked_stop_qty': '連動停損數量',
    'last_fill_time': '最後成交時間',
    'raw_json': '原始JSON',
    'callback_id': '回報ID',
    'event_type': '事件類型',
    'fill_notional': '成交金額',
    'callback_time': '回報時間',
    'ingested_at': '匯入時間',
    'reconcile_id': '對帳ID',
    'reconcile_time': '對帳時間',
    'order_mismatch_count': '委託不一致數',
    'fill_mismatch_count': '成交不一致數',
    'position_mismatch_count': '持倉不一致數',
    'lot_mismatch_count': '批次不一致數',
    'cash_diff': '現金差異',
    'summary_json': '摘要JSON',

    # tax lot accounting
    'tax_event_id': '稅務事件ID',
    'asset_class': '資產類別',
    'jurisdiction': '稅務管轄區',
    'tax_regime': '稅制分類',
    'tax_treatment': '稅務處理方式',
    'report_type': '報表類型',
    'exit_fill_id': '出場成交ID',
    'closed_qty': '平倉數量',
    'acquisition_date': '取得日期',
    'disposal_date': '處分日期',
    'cost_basis_price': '成本基礎價格',
    'close_price': '平倉價格',
    'gross_proceeds': '總處分收入',
    'allocated_cost_basis': '分攤成本基礎',
    'net_proceeds': '淨處分收入',
    'realized_gross_pnl': '已實現毛損益',
    'realized_net_pnl': '已實現淨損益',
    'taxable_gain_loss': '應稅損益',
    'ordinary_income_amount': '普通所得金額',
    'section1256_60pct_amount': '一二五六條款六成金額',
    'section1256_40pct_amount': '一二五六條款四成金額',
    'holding_period_days': '持有天數',
    'holding_period_bucket': '持有期間分類',
    'tax_year': '稅務年度',
    'wash_sale_applicable': '洗售規則適用',
    'wash_sale_applied': '洗售規則已套用',
    'wash_sale_adjustment': '洗售調整金額',
    'wash_sale_disallowed_loss': '洗售不得認列損失',
    'wash_sale_replacement_lot_ids': '洗售替代批次ID清單',
    'wash_sale_window_start': '洗售窗口開始日',
    'wash_sale_window_end': '洗售窗口結束日',
    'specific_id_tag': '指定批次標籤',
    'summary_id': '彙總ID',
    'open_lot_count': '未平倉批次數',
    'unrealized_net_pnl': '未實現淨損益',
}


def _quote_ident(name: str) -> str:
    return '[' + str(name).replace(']', ']]') + ']'


def _sql_n_literal(value: str) -> str:
    return "N'" + str(value).replace("'", "''") + "'"


def chinese_column_name(column_name: str) -> str:
    """回傳 SQL view 用中文欄名；原本已中文的欄位保持不變。"""
    if any('\u4e00' <= ch <= '\u9fff' for ch in column_name):
        return column_name
    return COLUMN_NAME_MAP.get(column_name, '欄位_' + column_name.replace('_', ''))


def iter_chinese_view_specs() -> list[dict[str, Any]]:
    specs: list[dict[str, Any]] = []
    for table in iter_table_specs():
        view_name = TABLE_VIEW_NAME_MAP.get(table.name, table.name + '_中文欄位')
        select_items: list[str] = []
        used_aliases: set[str] = set()
        for col in table.columns:
            alias = chinese_column_name(col.name)
            # SQL view 同一張表不可重複 alias；若遇到重名，補序號。
            if alias in used_aliases:
                base = alias
                i = 2
                while f'{base}_{i}' in used_aliases:
                    i += 1
                alias = f'{base}_{i}'
            used_aliases.add(alias)
            select_items.append(f'    {_quote_ident(col.name)} AS {_quote_ident(alias)}')
        specs.append({
            'table_name': table.name,
            'view_name': view_name,
            'select_items': select_items,
        })
    return specs


def ensure_chinese_column_views(db: Any) -> list[str]:
    """建立或重建所有中文欄名 view。"""
    actions: list[str] = []
    for spec in iter_chinese_view_specs():
        table_name = spec['table_name']
        view_name = spec['view_name']
        if not db.table_exists(table_name):
            actions.append(f'{table_name}:table_missing_skip_chinese_view')
            continue
        view_ident = _quote_ident(view_name)
        table_ident = _quote_ident(table_name)
        select_sql = ',\n'.join(spec['select_items'])
        create_view_sql = f"CREATE VIEW dbo.{view_ident} AS\nSELECT\n{select_sql}\nFROM dbo.{table_ident};"
        try:
            db.execute(
                f"IF OBJECT_ID({_sql_n_literal('dbo.' + view_name)}, N'V') IS NOT NULL DROP VIEW dbo.{view_ident};"
            )
            db.execute(create_view_sql)
            actions.append(f'{table_name}:created_view:{view_name}')
        except Exception as exc:
            record_issue(
                'sql_chinese_column_views',
                'create_chinese_column_view_failed',
                exc,
                severity='ERROR',
                fail_mode='fail_closed',
                context={'table': table_name, 'view': view_name},
            )
            actions.append(f'{table_name}:view_failed:{type(exc).__name__}:{exc}')
    return actions


if __name__ == '__main__':
    for item in iter_chinese_view_specs():
        print(f"{item['table_name']} -> {item['view_name']} ({len(item['select_items'])} columns)")
