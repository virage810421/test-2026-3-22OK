# -*- coding: utf-8 -*-
from fts_config import CONFIG, DB
from fts_utils import log, resolve_decision_csv
from fts_progress import ProgressTracker, VersionPolicy
from fts_logger import SQLLogger
from fts_broker_factory import create_broker
from fts_signal import SignalLoader, ExecutionReadinessChecker
from fts_report import ReportBuilder
from fts_tests import PreflightTestSuite
from fts_state import StateStore
from fts_compat import DecisionCompatibilityLayer
from fts_package_guard import PackageConsistencyGuard
from fts_runtime_ops_v59_patch import RuntimeLock
from fts_runtime_ops import HeartbeatWriter, ConfigSnapshotWriter
from fts_architecture_map import ArchitectureMapWriter
from fts_task_registry import TaskRegistry
from fts_orchestrator import UpstreamOrchestrator
from fts_dashboard import HealthDashboardBuilder
from fts_daily_ops import DailyOpsSummaryBuilder
from fts_gatekeeper import LaunchGatekeeper
from fts_ai_pipeline import AIPipelineRegistry, AIPipelineInspector, AIDecisionBridge
from fts_ai_manager import AITrainingManager
from fts_model_gate import ModelVersionRegistry
from fts_research_registry import ResearchSelectionRegistry
from fts_interface_audit import InterfaceAuditBuilder
from fts_stage_trace import StageTraceWriter
from fts_console_brief import ConsoleBriefBuilder
from fts_run_manifest import RunManifestBuilder
from fts_target95_scorecard import Target95Scorecard
from fts_target95_plan import Target95Planner
from fts_training_prod_readiness import TrainingProdReadinessBuilder
from fts_training_gap_report import TrainingGapReportBuilder
from fts_trainer_promotion_policy import TrainerPromotionPolicyBuilder
from fts_legacy_core_upgrade_plan import LegacyCoreUpgradePlanBuilder
from fts_legacy_core_readiness_board import LegacyCoreReadinessBoardBuilder
from fts_legacy_core_upgrade_wave import LegacyCoreUpgradeWaveBuilder
from fts_wave1_core_upgrade import Wave1CoreUpgradeBuilder
from fts_legacy_core_metrics import LegacyCoreMetricsBuilder
from fts_wave1_contract_pack import Wave1ContractPackBuilder
from fts_wave1_body_upgrade_templates import Wave1BodyUpgradeTemplatesBuilder
from fts_wave1_io_bindings import Wave1IOBindingsBuilder
from fts_wave1_upgrade_checklist import Wave1UpgradeChecklistBuilder

class FormalTradingSystemV61:
    def __init__(self):
        self.progress_tracker = ProgressTracker()
        self.version_policy = VersionPolicy()
        self.logger = SQLLogger(DB)
        self.broker = create_broker()
        self.signal_loader = SignalLoader()
        self.readiness_checker = ExecutionReadinessChecker()
        self.report_builder = ReportBuilder(self.progress_tracker, self.version_policy)
        self.preflight_tests = PreflightTestSuite()
        self.state_store = StateStore()
        self.compat_layer = DecisionCompatibilityLayer()
        self.package_guard = PackageConsistencyGuard()
        self.runtime_lock = RuntimeLock()
        self.heartbeat = HeartbeatWriter()
        self.config_snapshot = ConfigSnapshotWriter()
        self.architecture_map = ArchitectureMapWriter()
        self.task_registry = TaskRegistry()
        self.orchestrator = UpstreamOrchestrator()
        self.dashboard = HealthDashboardBuilder()
        self.daily_ops = DailyOpsSummaryBuilder()
        self.gatekeeper = LaunchGatekeeper()
        self.ai_registry = AIPipelineRegistry()
        self.ai_inspector = AIPipelineInspector()
        self.ai_bridge = AIDecisionBridge()
        self.ai_manager = AITrainingManager()
        self.model_registry = ModelVersionRegistry()
        self.research_registry = ResearchSelectionRegistry()
        self.interface_audit = InterfaceAuditBuilder()
        self.stage_trace = StageTraceWriter()
        self.console_brief = ConsoleBriefBuilder()
        self.run_manifest = RunManifestBuilder()
        self.target95_scorecard = Target95Scorecard()
        self.target95_plan = Target95Planner()
        self.training_prod_readiness = TrainingProdReadinessBuilder()
        self.training_gap_report = TrainingGapReportBuilder()
        self.trainer_promotion_policy = TrainerPromotionPolicyBuilder()
        self.legacy_core_upgrade_plan = LegacyCoreUpgradePlanBuilder()
        self.legacy_core_readiness_board = LegacyCoreReadinessBoardBuilder()
        self.legacy_core_upgrade_wave = LegacyCoreUpgradeWaveBuilder()
        self.wave1_core_upgrade = Wave1CoreUpgradeBuilder()
        self.legacy_core_metrics = LegacyCoreMetricsBuilder()
        self.wave1_contract_pack = Wave1ContractPackBuilder()
        self.wave1_body_upgrade_templates = Wave1BodyUpgradeTemplatesBuilder()
        self.wave1_io_bindings = Wave1IOBindingsBuilder()
        self.wave1_upgrade_checklist = Wave1UpgradeChecklistBuilder()

    def boot(self):
        log("=" * 60)
        log("🚀 啟動 正式交易主控版_v61")
        log(f"🧭 模式：{CONFIG.mode}")
        log(f"🏦 broker_type：{CONFIG.broker_type}")
        log("🧱 wave1 body templates + io bindings：ON")
        log(f"📈 目前整體升級進度：{self.progress_tracker.overall_percent()}%")
        log("=" * 60)
        if getattr(CONFIG, "enable_runtime_lock", False):
            self.runtime_lock.acquire()
        if getattr(CONFIG, "write_config_snapshot", False):
            self.config_snapshot.write()
        self.architecture_map.write()
        self.task_registry.write()
        self.ai_registry.build()
        self.ai_inspector.inspect()
        self.ai_bridge.build_summary()
        self.model_registry.build()
        self.research_registry.build()
        self.interface_audit.build()
        self.training_prod_readiness_path, _ = self.training_prod_readiness.build()
        self.training_gap_report_path, _ = self.training_gap_report.build()
        self.trainer_promotion_policy_path, _ = self.trainer_promotion_policy.build()
        self.legacy_core_upgrade_plan_path, _ = self.legacy_core_upgrade_plan.build()
        self.legacy_core_readiness_board_path, _ = self.legacy_core_readiness_board.build()
        self.legacy_core_upgrade_wave_path, _ = self.legacy_core_upgrade_wave.build()
        self.wave1_core_upgrade_path, _ = self.wave1_core_upgrade.build()
        self.legacy_core_metrics_path, _ = self.legacy_core_metrics.build()
        self.wave1_contract_pack_path, _ = self.wave1_contract_pack.build()
        self.wave1_body_upgrade_templates_path, _ = self.wave1_body_upgrade_templates.build()
        self.wave1_io_bindings_path, _ = self.wave1_io_bindings.build()
        self.wave1_upgrade_checklist_path, _ = self.wave1_upgrade_checklist.build()
        self.target95_scorecard_path, _ = self.target95_scorecard.build(self.progress_tracker.modules)
        self.target95_plan_path, _ = self.target95_plan.build(self.progress_tracker.modules)
        if self.logger.connect():
            self.logger.ensure_tables()

    def run(self):
        package_check = self.package_guard.run()
        ai_exec = self.ai_manager.maybe_run_training_stage()
        decision_path = resolve_decision_csv()
        normalized_df, compat_info = self.compat_layer.normalize(decision_path)
        readiness = self.readiness_checker.check(self.signal_loader.load_from_normalized_df(normalized_df))
        test_results = self.preflight_tests.run() if getattr(CONFIG, "enable_preflight_tests", False) else {}
        upstream_status = self.orchestrator.check_tasks(self.task_registry.summary())
        upstream_exec = self.orchestrator.execute_tasks(self.task_registry.summary())
        gate = self.gatekeeper.evaluate(upstream_status=upstream_status, upstream_exec=upstream_exec, retry_queue={}, compat_info=compat_info, readiness=readiness)
        execution_result = {"submitted": 0, "filled": 0, "partially_filled": 0, "rejected": 0, "cancelled": 0, "fills_count": 0, "auto_exit_signals": 0, "reconciliation": {}}
        account = self.broker.get_account_snapshot()
        self.stage_trace_path, _ = self.stage_trace.build(ai_exec=ai_exec, compat_info=compat_info, readiness=readiness, accepted_count=0, rejected_count=0, execution_result=execution_result)
        self.console_brief_path, console_brief = self.console_brief.build(ai_exec=ai_exec, compat_info=compat_info, readiness=readiness, research_gate={"go_for_decision_linkage": True}, model_gate={"go_for_model_linkage": True}, launch_gate=gate, live_safety={"paper_live_safe": True}, broker_approval={"go_for_broker_submission": False}, submission_gate={"go_for_submission_contract": False}, execution_result=execution_result)
        for line in self.console_brief.render_lines(console_brief):
            log(line)
        dashboard_path, dashboard = self.dashboard.build(upstream_status=upstream_status, upstream_exec=upstream_exec, retry_queue={}, readiness=readiness, execution_result=execution_result, positions=[])
        summary_path, alerts_path, _ = self.daily_ops.build(dashboard)
        state_path = self.state_store.save(cash=account.cash, positions=self.broker.get_positions(), last_prices=getattr(self.broker, "last_prices", {}), meta={"equity": account.equity, "exposure_ratio": account.exposure_ratio})
        generated_paths = {
            "training_prod_readiness_path": str(self.training_prod_readiness_path),
            "training_gap_report_path": str(self.training_gap_report_path),
            "trainer_promotion_policy_path": str(self.trainer_promotion_policy_path),
            "legacy_core_upgrade_plan_path": str(self.legacy_core_upgrade_plan_path),
            "legacy_core_readiness_board_path": str(self.legacy_core_readiness_board_path),
            "legacy_core_upgrade_wave_path": str(self.legacy_core_upgrade_wave_path),
            "wave1_core_upgrade_path": str(self.wave1_core_upgrade_path),
            "legacy_core_metrics_path": str(self.legacy_core_metrics_path),
            "wave1_contract_pack_path": str(self.wave1_contract_pack_path),
            "wave1_body_upgrade_templates_path": str(self.wave1_body_upgrade_templates_path),
            "wave1_io_bindings_path": str(self.wave1_io_bindings_path),
            "wave1_upgrade_checklist_path": str(self.wave1_upgrade_checklist_path),
            "stage_trace_path": str(self.stage_trace_path),
            "console_brief_path": str(self.console_brief_path),
            "dashboard_path": str(dashboard_path),
            "daily_ops_summary_path": str(summary_path),
            "alerts_path": str(alerts_path),
            "state_path": str(state_path),
        }
        self.run_manifest_path, _ = self.run_manifest.build(ai_exec=ai_exec, compat_info=compat_info, readiness=readiness, accepted_count=0, rejected_count=0, execution_result=execution_result, generated_paths=generated_paths)
        report_path = self.report_builder.save(package_check=package_check, compat_info=compat_info, readiness=readiness, test_results=test_results, accepted=[], rejected=[], execution_result=execution_result, account_snapshot=account, positions=self.broker.get_positions(), decision_path=decision_path, recovery_info={"recovered": False}, stage_results=generated_paths | {"run_manifest_path": str(self.run_manifest_path)})
        if getattr(CONFIG, "enable_heartbeat", False):
            self.heartbeat.write("run_complete", {"report_path": str(report_path), "wave1_body_upgrade_templates_path": str(self.wave1_body_upgrade_templates_path)})

    def shutdown(self):
        self.logger.close()
        if getattr(CONFIG, "enable_runtime_lock", False):
            self.runtime_lock.release()

def main():
    app = FormalTradingSystemV61()
    app.boot()
    app.run()
    app.shutdown()

if __name__ == "__main__":
    main()
