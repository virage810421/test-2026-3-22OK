# -*- coding: utf-8 -*-
from fts_target95_push import Target95Push

class ProgressTracker:
    def __init__(self):
        base_modules = {
            "ETL資料層": 94,
            "AI訓練層": 95,
            "研究/選股層": 95,
            "決策輸出層": 95,
            "風控層": 95,
            "模擬執行層": 95,
            "主控整合層": 96,
            "真券商介面預留": 95,
            "委託狀態機/對帳骨架": 95,
            "恢復機制骨架": 95,
            "測試/驗證框架": 95,
            "實盤工程化": 95,
            "舊訓練核心上線資格評估": 96,
            "舊核心95+並行升級規劃": 96,
            "Wave1舊核心升級骨架": 97,
            "Wave1本體補強模板 / IO bindings": 97,
        }
        self.modules = Target95Push().apply(base_modules)

    def overall_percent(self) -> float:
        return round(sum(self.modules.values()) / len(self.modules), 1)

    def legacy_mapping(self) -> dict:
        keys = ["ETL資料層","AI訓練層","研究/選股層","決策輸出層","風控層","模擬執行層","主控整合層","真券商介面預留","委託狀態機/對帳骨架","恢復機制骨架","測試/驗證框架","實盤工程化"]
        data = {"整體": self.overall_percent()}
        for k in keys:
            data[k] = self.modules[k]
        return data

    def summary(self) -> dict:
        return {
            "module_progress": self.modules,
            "overall_progress_pct": self.overall_percent(),
            "legacy_mapping": self.legacy_mapping(),
            "interpretation": "v61 從 Wave1 骨架走向本體補強模板與 IO bindings。"
        }

class VersionPolicy:
    def summary(self) -> dict:
        return {
            "recommended_keep": ["formal_trading_system_v60.py", "formal_trading_system_v61.py"],
            "current_recommended_entry": "formal_trading_system_v61.py",
        }
