# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any

from fts_prelive_runtime import PATHS, now_str, write_json


class LiveCutoverPlanBuilder:
    def build(self) -> tuple[str, dict[str, Any]]:
        steps = [
            {'seq': 1, 'name': '固定 broker contract', 'status': 'ready_now_before_account'},
            {'seq': 2, 'name': '固定 order state machine', 'status': 'ready_now_before_account'},
            {'seq': 3, 'name': '固定 callback schema', 'status': 'ready_now_before_account'},
            {'seq': 4, 'name': '建立 callback event store', 'status': 'ready_now_before_account'},
            {'seq': 5, 'name': '建立 operator approval registry', 'status': 'ready_now_before_account'},
            {'seq': 6, 'name': '建立 pre-open checklist', 'status': 'ready_now_before_account'},
            {'seq': 7, 'name': '建立 intraday incident guard', 'status': 'ready_now_before_account'},
            {'seq': 8, 'name': '建立 EOD closebook', 'status': 'ready_now_before_account'},
            {'seq': 9, 'name': '建立 live release gate', 'status': 'ready_now_before_account'},
            {'seq': 10, 'name': '券商 API 綁定', 'status': 'waiting_for_account_and_api'},
            {'seq': 11, 'name': 'callback / ledger 真實對帳綁定', 'status': 'waiting_for_account_and_api'},
            {'seq': 12, 'name': '實盤 cutover', 'status': 'waiting_for_account_and_api'},
        ]
        payload = {
            'generated_at': now_str(),
            'status': 'live_cutover_plan_defined',
            'steps': steps,
            'ready_now_count': sum(1 for x in steps if x['status'] == 'ready_now_before_account'),
            'waiting_count': sum(1 for x in steps if x['status'] != 'ready_now_before_account'),
        }
        path = PATHS.runtime_dir / 'live_cutover_plan.json'
        write_json(path, payload)
        return str(path), payload
