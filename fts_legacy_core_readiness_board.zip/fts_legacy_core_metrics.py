# -*- coding: utf-8 -*-
import json
from fts_config import PATHS, CONFIG
from fts_utils import now_str, log

class LegacyCoreMetricsBuilder:
    def __init__(self):
        self.path = PATHS.runtime_dir / "legacy_core_metrics.json"

    def build(self):
        payload = {
            "generated_at": now_str(),
            "system_name": CONFIG.system_name,
            "metrics": {
                "daily_chip_etl.py": {
                    "current_score": 89,
                    "target_score": 95,
                    "priority": "high"
                },
                "monthly_revenue_simple.py": {
                    "current_score": 90,
                    "target_score": 95,
                    "priority": "high"
                },
                "ml_data_generator.py": {
                    "current_score": 91,
                    "target_score": 95,
                    "priority": "high"
                }
            },
            "status": "metrics_ready"
        }
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        log(f"📏 已輸出 legacy core metrics：{self.path}")
        return self.path, payload
