# -*- coding: utf-8 -*-
import json
from fts_config import PATHS, CONFIG
from fts_utils import now_str, log

class RealAPIReadinessBuilder:
    def __init__(self):
        self.path = PATHS.runtime_dir / "real_api_readiness.json"

    def build(self):
        payload = {
            "generated_at": now_str(),
            "system_name": CONFIG.system_name,
            "target": "real_broker_api_and_real_market_binding",
            "completed_now": [
                "broker submission contract defined",
                "callback normalization contract defined",
                "live approval workflow reserved",
                "real broker stub reserved",
                "order payload preview contract defined",
            ],
            "missing_before_live": [
                "broker authentication and token refresh",
                "account routing: cash / margin / short-sell",
                "market session calendar and holiday source",
                "tick size / price band / odd-lot rules",
                "broker order id mapping and idempotency key",
                "real callback receiver and persistence",
                "partial fill reconciliation against broker ledger",
                "cancel/replace semantics for each broker",
                "rate limit and retry policy by endpoint",
                "live kill-switch and operator confirmation UX",
            ],
            "required_adapter_methods": {
                "connect": "建立 session / websocket / callback channel",
                "refresh_auth": "更新 token 或簽章",
                "place_order": "送出現股/融資/融券/零股單",
                "cancel_order": "撤單",
                "replace_order": "改價改量；若券商不支援需拆成 cancel+new",
                "get_order_status": "查詢委託狀態",
                "get_fills": "查詢成交回報",
                "get_positions": "查詢庫存",
                "get_cash": "查詢可用資金",
                "disconnect": "關閉連線",
            },
            "real_market_fields": [
                "market",
                "board",
                "currency",
                "order_type",
                "time_in_force",
                "session",
                "price_limit_up",
                "price_limit_down",
                "tick_size",
                "can_short",
                "can_margin_long",
                "lot_size",
                "odd_lot_allowed",
            ],
            "taiwan_equity_focus": {
                "mandatory_checks": [
                    "TW listed / OTC symbol normalization",
                    "1000-share board lot rule",
                    "odd-lot session / intraday rule separation",
                    "limit-up / limit-down validation",
                    "short-sell eligibility flag",
                    "現股 / 融資 / 融券 routing",
                ],
                "recommended_extensions": [
                    "broker reject reason classifier",
                    "pre-open / continuous / close auction session tagging",
                    "T+1 / T+2 settlement awareness for cash forecasting",
                ]
            },
            "api_bound": False,
            "callback_bound": False,
            "ledger_bound": False,
            "reconcile_bound": False,
            "kill_switch_bound": bool(getattr(CONFIG, "enable_live_kill_switch", True)),
            "true_broker_red_lights": {
                "api": "RED: no real SDK/session binding",
                "callback": "RED: no real callback receiver persistence",
                "ledger": "RED: no broker ledger import/account statement binding",
                "reconcile": "RED: no real broker ledger reconciliation proof",
                "kill_switch": "GREEN if enable_live_kill_switch is true, otherwise RED"
            },
            "status": "five_red_lights_until_real_broker_bound"
        }
        with open(self.path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        log(f"🛰️ 已輸出 real api readiness：{self.path}")
        return self.path, payload
